<?php

namespace App\Http\Controllers\Admins;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdminResource;
use App\Repositories\AdminRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdminsController extends Controller
{
    /**
     * Admin repository.
     *
     * @var App\Repositories\AdminRepository
     */
    protected $admin;
    
    /**
     * Create new instance of admin controller.
     *
     * @param AdminRepository admin Admin repository
     */
    public function __construct(AdminRepository $admin)
    {
        $this->admin = $admin;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! $data = AdminResource::collection($this->admin->paginate())) {
            return response()->json([
                'message'  => 'Failed to retrieve resource.'
            ], 400);
        }

        return $data;
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:admins',
            'password' => 'required|string|min:6|confirmed',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message'  => 'Validation failed.',
                'errors'   => $validator->errors()
            ], 400);
        }

        if (! $this->admin->store($request)) {
            return response()->json([
                'message'  => 'Failed to store resource.'
            ], 500);
        }

        return response()->json([
            'message'  => 'Resource successfully stored.'
        ], 200);
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! $admin = $this->admin->findOrFail($id)) {
            return response()->json([
                'message'  => 'Resource does not exist.'
            ], 400);
        }

        return response()->json([
            'message'     => 'Resource successfully retrieve.',
            'admin'       => $admin
        ], 200);
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message'  => 'Validation failed.',
                'errors'   => $validator->errors()
            ], 400);
        }

        if (! $this->admin->update($request, $id)) {
            return response()->json([
                'message'  => 'Failed to update resource.'
            ], 500);
        }

        return response()->json([
            'message'  => 'Resource successfully updated.'
        ], 200);
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! $this->admin->findOrFail($id)->delete()) {
            return response()->json([
                'message'  => 'Failed to delete resource.'
            ], 400);
        }

        return response()->json([
            'message'  => 'Resource successfully deleted.'
        ], 200);
    }
    
    /**
     * Restore the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        if (! $this->admin->restore($id)) {
            return response()->json([
                'message'  => 'Failed to restore resource.'
            ], 400);
        }

        return response()->json([
            'message'  => 'Resource successfully restored.'
        ], 200);
    }
    
    /**
     * Forcefully remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function forceDestroy($id)
    {
        if (! $this->admin->forceDestroy($id)) {
            return response()->json([
                'message'  => 'Failed to permanently delete resource.'
            ], 400);
        }

        return response()->json([
            'message'  => 'Resource successfully deleted permanently.'
        ], 200);
    }

    /**
     * Retrieve admin assigned roles.
     *
     * @param  int $id Admin ID
     * @return \Illuminate\Http\Response
     */
    public function getAssignedRoles($id)
    {
        return response()->json([
            'message'       => 'Successfully retrieve resource',
            'assignedRoles' => $this->admin->getAssignedRoles($id)
        ], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function toggleRole(Request $request)
    {
        if (! $this->admin->toggleRole($request)) {
            return response()->json([
                'message'  => 'Failed to toggle role.'
            ], 400);
        }

        return response()->json([
            'message'  => 'Role successfully toggled.'
        ], 200);
    }
}
