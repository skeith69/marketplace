<?php

Route::group(['namespace' => 'Admins', 'domain' => 'admin.marketplace.test'], function () {
    Auth::routes();

    Route::get('/{any}', 'SpaController@index')->where('any', '.*')->name('admins.index');
});

Route::group(['namespace' => 'Users', 'domain' => 'marketplace.test'], function () {
    Route::get('/{any}', 'SpaController@index')->where('any', '.*')->name('users.index');
});
